# Photo Blog - Android Blog App with Firebase

[![N|Solid](https://i.imgur.com/Uy3OwII.png)](https://nodesource.com/products/nsolid)

This Project is based on "Android Blog App 2018 - Android Studio Firebase Tutorials" Tutorial Series and is not finished yet. The reason of upload is to provide source code for viewers.

Source Code will be updated along with new Videos. Current Progress (Till Part 18 + Bug Fixes)

# Tutorial Link : 

[Youtube Playlist - Android Blog App 2018 - Android Studio Firebase Tutorials ](https://www.youtube.com/playlist?list=PLGCjwl1RrtcR4ptHvrc_PQIxDBB5MGiJA)

# Important Note : 
The "google-services.json" file is modified and project info is removed for security purpose. To use this project you may need to import "google-services.json" file from your own Firebase Project.
