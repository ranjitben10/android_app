
    // setTimeout(()=>{
    //     const xhr=new XMLHttpRequest();
    // xhr.open("GET",'home1.pug',true)
    // xhr.onprogress=function(){
    //     res.render('loader.pug')
    // }
    // xhr.onload=function(){
    //     if(this.status===200){
    //         console.log("loaded");            
    //     }
    // }
    // xhr.send();
    // },2000)
const time=document.getElementById("time");
setInterval(()=>{
    let date=new Date();
    time.innerHTML=`<p style="border-radius:12px;color:black">${date}</p>`;
})
const video=document.getElementsByClassName("videobg");
const change=document.getElementById("change");
// console.log(video,change)
change.addEventListener("click",function(){
    video[0].innerHTML=`<video src="https://player.vimeo.com/external/308049044.sd.mp4?s=e96aa7006ad79744b025955731c881b6a44ac901&profile_id=164&oauth2_token_id=57447761" autoplay muted loop id="video">Eat Fresh And Live Healthy</video>`
})
const images=document.getElementsByClassName("op");
console.log(images)
function lightup(value){
Array.from(images).forEach((element)=>{
    console.log(element)
    element.style.opacity=value;
})
}
setInterval(()=>{
    val=0.5+(1-0.5)*Math.random()
    lightup(val)
},2000)
const signup=document.getElementById("signup");
setTimeout(()=>{
    signup.style.display="none";
},6000)
  
