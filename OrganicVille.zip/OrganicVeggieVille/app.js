const express=require("express");
const path=require("path");
const fs=require("fs");
const app=express();
const port=80;
const bodyParser=require("body-parser")
const mongoose=require("mongoose");
mongoose.connect('mongodb+srv://ranjitben10:ranjit@cluster0-gwrnx.mongodb.net/OrganicVille?retryWrites=true&w=majority',{useNewUrlParser:true, useUnifiedTopology: true });
const db=mongoose.connection;
db.on('error',console.error.bind(console,'connection error'));
db.once('open',function callback(){
    console.log("ok connected");
})
//express specific stuff
app.use('/static',express.static('static'));//for serving static files
//pug specific stuff
app.set('view engine','pug');//Set the template engine as pug
app.set('views',path.join(__dirname,'views'));//set the views directory
//Endpoints
app.get('/',(req,res)=>{
    res.status(200).render("login.pug");
})
app.get('/logup',(req,res)=>{
    res.status(200).render("signup.pug");
})
app.get('/login',(req,res)=>{
    res.status(200).render("login.pug");
})
app.get('/product',(req,res)=>{
    // const params={};
    res.status(200).render('product.pug');
})
app.get('/contact',(req,res)=>{
    res.status(200).render('contact.pug');
})
app.use(bodyParser.urlencoded({extended:true}))
app.use(bodyParser.json())
const users=require("./models/User")
app.post("/signup",(req,res)=>{
    let name=req.body.name;
    let email=req.body.email;
    let pass=req.body.pass;
    newUsers=new users({
        name:name,
        email:email,
        password:pass
    })
    newUsers.save(err=>{
        if(err){
            console.log(err)
        }
        else{
            res.status(200).render("login.pug")
        }
    })
})
app.post("/signin",(req,res)=>{

    let mail=req.body.email;
    let pass=req.body.pass;
    // console.log(mail,pass)
    
    users.find({email:mail,password:pass},(err,user)=>{
        // console.log(users)
        
        if(user[0].email===mail && user[0].password===pass){
            
            res.status(200).render("home1.pug",{user:user})
        }
        else{
            res.render("login")
        // res.status(200).render("home1.pug")
        }
    })
})
//start the server
app.listen(port,()=>{
    console.log("Srever Started");
})