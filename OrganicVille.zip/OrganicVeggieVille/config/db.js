module.exports={
    mongoURI:"mongodb+srv://ranjitben10:ranjit@cluster0-gwrnx.mongodb.net/test?retryWrites=true&w=majority"
}