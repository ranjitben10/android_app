# adhoc-portfolio
My portfolio specifically for Chicago Digital since I haven't updated my page in a long while :) and also for fun!!!
